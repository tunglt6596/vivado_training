//-----------------------------------------------------------------------------
//   ____  ____
//  /   /\/   /
// /___/  \  /   Vendor: Xilinx
// \   \   \/    Version: 1.0
//  \   \        Filename: $RCSfile: v_rgb2ycrcb_v7_1_bitacc_cmodel.h,v $
//  /   /        Date Last Modified: $Date: 2010/02/25 14:09:33 $
// /___/   /\    Date Created: 2010
// \   \  /  \
//  \___\/\___\
//
// Devices : All
// Library : RGB to YCrCb Color-correction
// Purpose : Header file for bit accurate C model
//-----------------------------------------------------------------------------
//  (c) Copyright 2009 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-----------------------------------------------------------------------------
//
// Header file for the bit-accurate ANSI C reference model 
// for the Xilinx Color Filter Array Interpolation core

#ifndef v_rgb2ycrcb_v7_1_bitacc_cmodel_h
#define v_rgb2ycrcb_v7_1_bitacc_cmodel_h

#ifdef NT
#define DLLIMPORT __declspec(dllimport)
#else
#define DLLIMPORT
#endif

#ifndef Ip_xilinx_ip_v_rgb2ycrcb_v7_1_DLL
#define Ip_xilinx_ip_v_rgb2ycrcb_v7_1_DLL DLLIMPORT
#endif

#ifdef  __cplusplus
extern "C" {
#endif

#ifndef rgb_utils_h
#include "rgb_utils.h"
#endif

#ifndef yuv_utils_h
#include "yuv_utils.h"
#endif

#ifndef video_utils_h   // video_struct is defined here
#include "video_utils.h"
#endif

struct rgb_coef_inputs
{
  /* Pre-translated coefficient/offset data */
  int     IWIDTH;         //@- Input data width: 8, 10, 12 or 16 bits 
  double  ACOEF;          //@- [ 0.0 - 1.0 ]       0.0 < ACOEFF + BCOEFF < 1.0
  double  BCOEF;          //@- [ 0.0 - 1.0 ]       0.0 < ACOEFF + BCOEFF < 1.0
  double  CCOEF;          //@- [ 0.0 - 0.9 ]
  double  DCOEF;          //@- [ 0.0 - 0.9 ]
  int     YOFFSET;        //@- Offset for the Luminance Channel
  int     CBOFFSET;       //@- Offset for the Chrominance Channels
  int     CROFFSET;       //@- Offset for the Chrominance Channels
};

struct rgb_coef_outputs
{
  /* Translated coefficient/offset data */
  int     IWIDTH;       //@- Input data width: 8, 10, 12 or 16 bits 
  int     ACOEF;        //@- Translated ACoef
  int     BCOEF;        //@- Translated BCoef
  int     CCOEF;        //@- Translated CCoef
  int     DCOEF;        //@- Translated DCoef
  int     YOFFSET;        //@- Offset for the Luminance Channel
  int     CBOFFSET;       //@- Offset for the Chrominance Channels
  int     CROFFSET;       //@- Offset for the Chrominance Channels
};
struct xilinx_ip_v_rgb2ycrcb_v7_1_generics
{
/**
 * RGB to YCrCb / YUV v3.0 Core Generics
 * These are the generics that influence the operation of this bit-accurate model.
 */
  int     ACTIVE_COLS;              //@- Active # of Columns
  int     ACTIVE_ROWS;              //@- Active # of Rows
  struct rgb_coef_inputs  COEF_IN;  //@- Pre-translated coefficient/offset data
  struct rgb_coef_outputs COEF_OUT; //@- Translated coefficiant/offset data
  int     YMAX;                     //@- Clipping value for the Luminance Channel
  int     YMIN;                     //@- Clamping value for the Luminance Channel
  int     CBMAX;                    //@- Clipping value for the Cb Chrominance Channel
  int     CBMIN;                    //@- Clamping value for the Cb Chrominance Channel
  int     CRMAX;                    //@- Clipping value for the Cr Chrominance Channel
  int     CRMIN;                    //@- Clamping value for the Cr Chrominance Channel
  int     HAS_CLIP;                 //@- Has CLIP Circuit
  int     HAS_CLAMP;                //@- Has Clamp Circuit
  int     STANDARD_SEL;             //@- Standard Selection 0=SD_ITU_601, 1=HD_ITU_709__1125_NTSC
                                    //@-  2=HD_ITU_709__1250_PAL, 3=YUV, 4=Custom
  int     OUTPUT_RANGE;              //@- Input Range 0=16_to_240_for_TV, 1=16_to_235_for_Studio_Equipment, 
                                    //@-  2=0_to_255_for_Computer_Graphics
  int     HAS_AXI4_LITE;            //@- Has AXI4-Lite Processor Interface
  int     HAS_INTC_IF;              //@- HAS INTC_IF debug port
  int     HAS_DEBUG;                 //@- Has Debug circuitry enabled
}; // xilinx_ip_v_rgb2ycrcb_v7_1_generics

/**
 * Get list of default generics.
 *
 * @returns xilinx_ip_v_rgb2ycrcb_v7_1_generics  Default generics.
 */
Ip_xilinx_ip_v_rgb2ycrcb_v7_1_DLL int xilinx_ip_v_rgb2ycrcb_v7_1_get_default_generics(
      struct xilinx_ip_v_rgb2ycrcb_v7_1_generics *generics);

/**
 * Get list of default inputs.
 *
 * @returns 0 if successful, error code otherwise.
 */
Ip_xilinx_ip_v_rgb2ycrcb_v7_1_DLL int xilinx_ip_v_rgb2ycrcb_v7_1_get_default_inputs(
      struct xilinx_ip_v_rgb2ycrcb_v7_1_generics *generics, 
      struct xilinx_ip_v_rgb2ycrcb_v7_1_inputs *inputs);

/**
 * Structure to capture all inputs to the YCrCb to RGB v3.0 C-Model.
 *
 * @param video_in          Input data and formatting, provided as a pointer to video_struct.
 *                          video_struct elements are:
 *                          mode : RGB format is used
 *                          data[plane][frame][row][col] : data structure containing 16 bit unsigned elements.
 *                          frames: number of frames in the data structure
 *                          rows  : number of rows in the data structure
 *                          cols  : number of columns in the data structure
 *                          bits_per_component: number of bits stored per color component 
 *                          The user is responsible for properly allocating the data field, and initializing all fields 
 *                          of the video_struct.
 * 
 */
struct xilinx_ip_v_rgb2ycrcb_v7_1_inputs
{
  struct  video_struct video_in;     //@- Contains the input data, and formatting (frames, rows, color)
  int     ACTIVE_ROWS;               //@- Active # of Columns
  int     ACTIVE_COLS;               //@- Active # of Rows
  struct rgb_coef_inputs  COEF_IN;   //@- Pre-translated coefficient/offset data
  struct rgb_coef_outputs COEF_OUT;  //@- Translated coefficiant/offset data
  int     YMAX;                      //@- Clipping value for the Luminance Channel
  int     YMIN;                      //@- Clamping value for the Luminance Channel
  int     CBMAX;                     //@- Clipping value for the Cb Chrominance Channel
  int     CBMIN;                     //@- Clamping value for the Cb Chrominance Channel
  int     CRMAX;                     //@- Clipping value for the Cr Chrominance Channel
  int     CRMIN;                     //@- Clamping value for the Cr Chrominance Channel
}; // end xilinx_ip_v_rgb2ycrcb_v7_1_inputs


/**
 * Structure to capture all outputs from the rgb2ycrcb v2.0 C-Model.
 *
 * Before using this structure the user is responsible defining the output video_struct.
 * If the data structure in the output video_struct is preallocated, the model 
 * automatically uses the preallocated memory, but checks whether the formatting 
 * of the output video_stuct (number of frames, rows, columns) is compatible with the 
 * corresponding parameters of the input video_struct.
 *
 * @param video_out      Output data and formatting, provided as a pointer to video_struct.
 *                       Video_struct elements are:
 *                       data[color_channel][frame][row][col] containing 16 bit unsigned elements.
 *                       frames: number of frames in the data structure
 *                       rows  : number of rows in the data structure
 *                       cols  : number of columns in the data structure
 *                       bits_per_component: number of bits stored per color component 
 */
struct xilinx_ip_v_rgb2ycrcb_v7_1_outputs
{
  struct video_struct video_out;  //@- Contains the input data, and formatting (frames, rows, color)
}; // xilinx_ip_v_rgb2ycrcb_v7_1_outputs

/**
 * Destroy the input / output video structure.
 *
 * @param *inputs       Pointer to the input structure which contains a yuv_video structure 
 *                      to be destroyed (freed in memory).
 * @param *outputs      Pointers to the output structure which contains a yuv_video structure 
 *                      to be destroyed (freed in memory).
 */
Ip_xilinx_ip_v_rgb2ycrcb_v7_1_DLL void xilinx_ip_v_rgb2ycrcb_v7_1_destroy(
        struct xilinx_ip_v_rgb2ycrcb_v7_1_inputs *input, 
        struct xilinx_ip_v_rgb2ycrcb_v7_1_outputs *output);

/**
 * Simulate this bit-accurate C-Model.
 *
 * @param     generics   Inputs to the C-Model specified through Core Generator Generics
 * @param     inputs     Inputs to the C-Model specified through signals
 * @param     outputs    Outputs from this C-Model.
 *
 * @returns   Exit code   Zero for SUCCESS, Non-zero otherwise.
 */
Ip_xilinx_ip_v_rgb2ycrcb_v7_1_DLL int xilinx_ip_v_rgb2ycrcb_v7_1_bitacc_simulate(
 struct xilinx_ip_v_rgb2ycrcb_v7_1_generics* generics,
 struct xilinx_ip_v_rgb2ycrcb_v7_1_inputs*   inputs,
 struct xilinx_ip_v_rgb2ycrcb_v7_1_outputs*  outputs);



/*
 * Translate between the input coefficients and the output coefficients.
 */
Ip_xilinx_ip_v_rgb2ycrcb_v7_1_DLL 
int rgb2ycrcb_coefficient_translation(struct rgb_coef_inputs *coef_in, struct rgb_coef_outputs *coef_out);


#ifdef  __cplusplus
}
#endif


#endif // v_rgb2ycrcb_v7_1_bitacc_cmodel_h 
